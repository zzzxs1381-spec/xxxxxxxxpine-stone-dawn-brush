import { useEffect, useRef, useState } from "react";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button.tsx";
import { TextInput } from "@/components/ui/field.tsx";
import { askEvidence, localSourceSearch, type AskPayload } from "@/lib/assistant/server.ts";
import { formatPlain } from "@/lib/mizan/decimal.ts";
import { getProfile } from "@/lib/mizan/profiles.ts";
import { SOURCES } from "@/lib/mizan/sources.ts";
import { useMizan } from "@/stores/mizan-store.ts";

type Log = { role: "user" | "sheikh"; text: string };

export function SheikhSheet({
  open,
  seed,
  onClose,
}: {
  open: boolean;
  seed: string;
  onClose: () => void;
}) {
  const result = useMizan((s) => s.lastResult);
  const input = useMizan((s) => s.input);
  const [q, setQ] = useState("");
  const [log, setLog] = useState<Log[]>([]);
  const [busy, setBusy] = useState(false);
  const seeded = useRef("");
  const scroller = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) {
      seeded.current = "";
      return;
    }
    if (seed && seed !== seeded.current) {
      seeded.current = seed;
      void send(seed);
    }
  }, [open, seed]);

  useEffect(() => {
    scroller.current?.scrollTo({ top: scroller.current.scrollHeight, behavior: "smooth" });
  }, [log, busy]);

  async function send(raw?: string) {
    const question = (raw ?? q).trim();
    if (!question || busy) return;
    setQ("");
    setLog((l) => [...l, { role: "user", text: question }]);
    setBusy(true);
    const local = localSourceSearch(question);
    const excerpts = (local.length ? local : SOURCES.slice(0, 6)).map((s) => ({
      id: s.sourceId,
      title: s.title,
      locator: s.locator,
      notes: s.notes,
      arabic: s.arabic,
    }));
    const payload: AskPayload = {
      question,
      profileId: input.profileId,
      profileName: getProfile(input.profileId).name,
      anonymized: {
        overallStatus: result?.overallStatus ?? "unknown",
        completeness: result?.completeness ?? "partial",
        categories: (result?.categories ?? []).map((c) => ({
          id: c.id,
          status: c.status,
          zakat: c.zakatMoney !== undefined ? formatPlain(c.zakatMoney) : undefined,
          natural: c.natural?.map((n) => n.label),
        })),
        missing: result?.missing ?? [],
      },
      sourceExcerpts: excerpts,
    };
    try {
      const res = await askEvidence({ data: payload });
      if (res.ok) {
        setLog((l) => [...l, { role: "sheikh", text: res.text }]);
      } else {
        const fallback = excerpts.map((s) => `• ${s.title}: ${s.notes}`).join("\n");
        setLog((l) => [
          ...l,
          {
            role: "sheikh",
            text: `${res.error}\n\nМир тебе. Из сохранённых источников:\n${fallback}`,
          },
        ]);
      }
    } catch {
      setLog((l) => [
        ...l,
        { role: "sheikh", text: "Сейчас без сети. Откройте Коран или урок — я не ушёл." },
      ]);
    } finally {
      setBusy(false);
    }
  }

  if (!open) return null;
  return (
    <div className="sheikh-sheet" role="presentation" onClick={onClose}>
      <div
        className="sheikh-sheet-card"
        role="dialog"
        aria-labelledby="sheikh-title"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-3 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <img src="/brand/sheikh-seal.jpg" alt="" className="sheikh-seal sheikh-seal-sm" width={44} height={44} />
            <div>
              <p id="sheikh-title" className="font-display text-xl leading-none">
                Шейх
              </p>
              <p className="mt-1 text-xs text-[var(--muted)]">Мир тебе</p>
            </div>
          </div>
          <Button variant="ghost" className="pill size-11 p-0" onClick={onClose} aria-label="Закрыть">
            <X className="size-5" />
          </Button>
        </div>
        <div ref={scroller} className="min-h-0 overflow-y-auto pr-1 text-sm leading-relaxed">
          {log.length === 0 && !busy ? (
            <p className="text-[var(--muted)]">Спроси про закят, нисаб, Коран или с чего начать учить.</p>
          ) : null}
          {log.map((m, i) => (
            <div
              key={i}
              className={
                m.role === "user"
                  ? "mb-2 ml-8 rounded-2xl bg-[var(--bg-elev)] px-3 py-2"
                  : "mb-3 mr-4 border-l-2 border-[var(--accent)] pl-3"
              }
            >
              <p className="whitespace-pre-wrap">{m.text}</p>
            </div>
          ))}
          {busy ? <p className="text-xs text-[var(--muted)]">Шейх смотрит источники…</p> : null}
        </div>
        <div className="mt-3 flex gap-2">
          <TextInput
            value={q}
            placeholder="Спроси шейха…"
            onChange={(e) => setQ(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") void send();
            }}
          />
          <Button onClick={() => void send()} disabled={busy} className="pill">
            Сказать
          </Button>
        </div>
      </div>
    </div>
  );
}
