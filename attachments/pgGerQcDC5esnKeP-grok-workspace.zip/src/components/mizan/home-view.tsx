import { useEffect, useState } from "react";
import { BookOpen, GraduationCap, Play, Scale, Send } from "lucide-react";
import { SheikhSheet } from "@/components/mizan/sheikh-sheet.tsx";
import { Button } from "@/components/ui/button.tsx";
import { formatMoney } from "@/lib/mizan/decimal.ts";
import { PROGRAM, weekByN } from "@/lib/quran/curriculum.ts";
import { dayAyahRef, formatRef, loadAyah } from "@/lib/quran/mushaf.ts";
import { RECITERS } from "@/lib/quran/reciters.ts";
import type { Ayah } from "@/lib/quran/types.ts";
import { useLearn } from "@/stores/learn-store.ts";
import { useMizan } from "@/stores/mizan-store.ts";
import { useQuran } from "@/stores/quran-store.ts";

const MET_KEY = "mizan.v1.sheikhMet";

function alreadyMet() {
  try {
    return localStorage.getItem(MET_KEY) === "1";
  } catch {
    return false;
  }
}

function markMet() {
  try {
    localStorage.setItem(MET_KEY, "1");
  } catch {
    /* ignore */
  }
}

export function HomeView() {
  const setTab = useMizan((s) => s.setAppTab);
  const setZakatOpen = useMizan((s) => s.setZakatOpen);
  const result = useMizan((s) => s.lastResult);
  const weekN = useLearn((s) => s.week);
  const week = weekByN(weekN);
  const playAt = useQuran((s) => s.playAt);
  const [daily, setDaily] = useState<{ ref: { surah: number; ayah: number }; ayah: Ayah | null } | null>(null);
  const [returning, setReturning] = useState(false);
  const [ask, setAsk] = useState("");
  const [sheetOpen, setSheetOpen] = useState(false);
  const [seed, setSeed] = useState("");

  useEffect(() => {
    setReturning(alreadyMet());
    markMet();
    const ref = dayAyahRef();
    void loadAyah(ref.surah, ref.ayah).then((ayah) => setDaily({ ref, ayah }));
  }, []);

  function openSheikh(question?: string) {
    setSeed(question ?? "");
    setSheetOpen(true);
  }

  function listenFatiha() {
    useQuran.getState().setReciter("ar.husary");
    playAt(1, 1, 7);
  }

  return (
    <div className="page-pad home-stage mx-auto grid max-w-2xl gap-6 px-4 pt-2">
      <section className="home-stagger grid justify-items-center text-center">
        <p className="bismillah" lang="ar">
          بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ
        </p>
        <button type="button" className="sheikh-seal-btn" aria-label="Спросить шейха" onClick={() => openSheikh()}>
          <i className="sheikh-ring" aria-hidden />
          <i className="sheikh-ring" aria-hidden />
          <img src="/brand/sheikh-seal.jpg" alt="" width={128} height={128} />
        </button>
        <div className="mt-5 grid gap-1">
          <p className="salam-ar greet-line" lang="ar" style={{ animationDelay: "40ms" }}>
            السلام عليكم
          </p>
          {returning ? (
            <p className="greet-line home-hero" style={{ animationDelay: "180ms" }}>
              Мир тебе.
            </p>
          ) : (
            <>
              <p className="greet-line home-hero" style={{ animationDelay: "180ms" }}>
                Мир тебе.
              </p>
              <p className="greet-line mt-2 text-lg text-[var(--muted)]" style={{ animationDelay: "320ms" }}>
                Я шейх.
              </p>
            </>
          )}
        </div>
      </section>

      <form
        className="ask-pill"
        onSubmit={(e) => {
          e.preventDefault();
          const t = ask.trim();
          if (!t) {
            openSheikh();
            return;
          }
          setAsk("");
          openSheikh(t);
        }}
      >
        <input
          className="min-w-0 flex-1 bg-transparent text-sm outline-none placeholder:text-[var(--muted)]"
          value={ask}
          placeholder="Спроси шейха…"
          onChange={(e) => setAsk(e.target.value)}
        />
        <Button type="submit" variant="glow" className="size-11 shrink-0 p-0" aria-label="Спросить шейха">
          <Send className="size-4" />
        </Button>
      </form>

      <div className="chip-row">
        <button type="button" className="quiet-chip" onClick={() => setTab("learn")}>
          С чего начать учить
        </button>
        <button type="button" className="quiet-chip" onClick={() => openSheikh("Что такое нисаб, простыми словами?")}>
          Что такое нисаб
        </button>
        <button type="button" className="quiet-chip" onClick={listenFatiha}>
          Послушай Фатиху
        </button>
      </div>

      <article className="ayah-card">
        <p className="text-[11px] uppercase tracking-[0.16em] text-[var(--muted)]">Аят дня</p>
        {daily?.ayah ? (
          <>
            <p className="ayah-ar mt-3" lang="ar">
              {daily.ayah.ar}
            </p>
            <p className="mt-3 text-[15px] leading-relaxed">{daily.ayah.ru}</p>
            <p className="mt-2 text-[11px] text-[var(--muted)]">
              {formatRef(daily.ref.surah, daily.ref.ayah)} · перевод Кулиева
            </p>
            <div className="mt-4 flex flex-wrap gap-2">
              <Button
                variant="glow"
                className="flex-1"
                onClick={() => {
                  useQuran.getState().setReciter("ar.husary");
                  playAt(daily.ref.surah, daily.ref.ayah, daily.ref.ayah);
                }}
              >
                <Play className="size-4" /> Слушать Хусари
              </Button>
              <Button variant="secondary" className="pill" onClick={() => setTab("quran")}>
                Весь Коран
              </Button>
            </div>
          </>
        ) : (
          <p className="mt-3 text-sm text-[var(--muted)]">Открываю мусхаф…</p>
        )}
      </article>

      <div className="grid gap-3">
        <p className="text-[11px] uppercase tracking-[0.16em] text-[var(--muted)]">Что здесь есть</p>
        <button type="button" className="door" onClick={() => setTab("learn")}>
          <span className="inline-flex items-center gap-2 text-[11px] uppercase tracking-[0.14em] text-[var(--muted)]">
            <GraduationCap className="size-4" /> Сегодня учим
          </span>
          <span className="font-display text-2xl leading-tight">{week.title}</span>
          <span className="text-sm text-[var(--muted)]">
            {PROGRAM.name} · неделя {week.n} из {PROGRAM.weeks}. {week.goal}
          </span>
        </button>
        <button
          type="button"
          className="door"
          onClick={() => {
            setTab("zakat");
            setZakatOpen(false);
          }}
        >
          <span className="inline-flex items-center gap-2 text-[11px] uppercase tracking-[0.14em] text-[var(--muted)]">
            <Scale className="size-4" /> Закят
          </span>
          <span className="font-display text-3xl leading-none tabular-nums text-[var(--ok)]">
            {result ? formatMoney(result.totalMoneyRounded, result.baseCurrency) : "—"}
          </span>
          <span className="text-sm text-[var(--muted)]">Посчитать по своим деньгам, золоту, скоту. С источниками рядом.</span>
        </button>
        <button type="button" className="door" onClick={() => setTab("quran")}>
          <span className="inline-flex items-center gap-2 text-[11px] uppercase tracking-[0.14em] text-[var(--muted)]">
            <BookOpen className="size-4" /> Коран
          </span>
          <span className="font-display text-2xl leading-tight">Кулиев · 114 сур</span>
          <span className="text-sm text-[var(--muted)]">
            Полный текст и смысл. {RECITERS.length} чтецов, первым — Хусари.
          </span>
        </button>
      </div>

      <ul className="grid grid-cols-2 gap-2 text-xs text-[var(--muted)]">
        <li className="rounded-2xl border border-[var(--line)] px-3 py-3">114 сур · 6236 аятов</li>
        <li className="rounded-2xl border border-[var(--line)] px-3 py-3">Перевод Эльмира Кулиева</li>
        <li className="rounded-2xl border border-[var(--line)] px-3 py-3">Хусари, Миншави, Афаси</li>
        <li className="rounded-2xl border border-[var(--line)] px-3 py-3">Иткан — 40 недель</li>
      </ul>

      <SheikhSheet open={sheetOpen} seed={seed} onClose={() => setSheetOpen(false)} />
    </div>
  );
}
